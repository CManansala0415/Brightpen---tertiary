<script setup>
import { ref, onMounted, computed } from 'vue';
</script>

<template>
    <div class="">
        Courses Here
    </div>
</template>
