<script setup>
import { ref, onMounted, computed } from 'vue';

</script>
<template>
   <div class="flex flex-col w-full h-full">
      <div class="h-28"></div>
      <div class="flex gap-2 w-full h-full">
         <div class=" basis-3/12 flex flex-col gap-2 p-5">
            
           
         </div>
         <div class=" basis-full border-x border-gray-300 flex flex-col gap-2 p-5">
            <div class="mt-5">
               <p class="text-md font-extrabold">Home</p>
            </div>
            <div class="w-full p-5">
            </div>
         </div>
         <div class=" basis-3/12 flex flex-col gap-2 p-5">
           
         </div>
      </div>
   </div>
</template>